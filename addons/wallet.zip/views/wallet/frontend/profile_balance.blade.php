<h3 class="section__title font-size-24"> <i class="fa fa-money"></i> {{ walletBalance() }}</h3>
<a href="{{ route('recharge.wallet', generateToken()) }}" class="btn btn-success">Top Up</a>